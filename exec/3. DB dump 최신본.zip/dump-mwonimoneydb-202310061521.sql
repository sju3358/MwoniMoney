-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: j9b310.p.ssafy.io    Database: mwonimoneydb
-- ------------------------------------------------------
-- Server version	11.1.2-MariaDB-1:11.1.2+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add test',7,'add_test'),(26,'Can change test',7,'change_test'),(27,'Can delete test',7,'delete_test'),(28,'Can view test',7,'view_test'),(29,'Can add balance',8,'add_balance'),(30,'Can change balance',8,'change_balance'),(31,'Can delete balance',8,'delete_balance'),(32,'Can view balance',8,'view_balance'),(33,'Can add challenge',9,'add_challenge'),(34,'Can change challenge',9,'change_challenge'),(35,'Can delete challenge',9,'delete_challenge'),(36,'Can view challenge',9,'view_challenge'),(37,'Can add quiz',10,'add_quiz'),(38,'Can change quiz',10,'change_quiz'),(39,'Can delete quiz',10,'delete_quiz'),(40,'Can view quiz',10,'view_quiz');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$600000$1IWcTE90MmZ8dF78mEcTzf$1BahEEoyd6bDPuMo5K/f5CWoDH6v8bbN9QtLE4c3dSk=','2023-10-06 02:06:11.537013',1,'ssafy-b310','','','aldms8960@naver.com',1,1,'2023-09-22 04:42:34.585638');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance` (
  `idx` bigint(20) NOT NULL AUTO_INCREMENT,
  `balance_status` varchar(255) DEFAULT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `balance_left_answer` varchar(255) DEFAULT NULL,
  `balance_news` varchar(255) DEFAULT NULL,
  `balance_question` varchar(255) DEFAULT NULL,
  `balance_right_answer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
INSERT INTO `balance` VALUES (1,'RUNNING','2023-09-30 10:05:11.260927','용돈','살만한가요?','돈이 갑자기 필요할 떄 졸라서 용돈? or 집안일?','집안일'),(2,'RUNNING','2023-09-30 10:05:19.051795','네','아닌가요','10000원을 갑자기 받았을 때 저축할껀가요?','아니요'),(3,'RUNNING','2023-09-30 10:05:26.445547','주식','맞습니다','만약 100만원이 주어진다면 주식? or 저축','저축'),(5,'WAIT','2023-10-04 20:32:35.000000','LEFT','NEWS','QUESTION1','RIGHT'),(6,'END','2023-10-04 20:32:36.000000','LEFT','NEWS','QUESTION2','RIGHT'),(7,'END','2023-10-04 20:32:36.000000','LEFT','NEWS','QEUSTION3','RIGHT'),(8,'END','2023-10-04 20:32:37.000000','LEFT','NEWS','QUESTION4','RIGHT'),(9,'END','2023-10-04 20:32:37.000000','LEFT','NEWS','QUESTION5','RIGHT'),(10,'END','2023-10-04 20:32:38.000000','LEFT','NEWS','QUESTION6','RIGHT'),(11,'END','2023-10-04 20:32:37.000000','LEFT','NEWS','QUESTION7','RIGHT'),(12,'END','2023-10-04 20:32:39.000000','LEFT','NEWS','QUESTION8','RIGHT'),(13,'END','2023-10-04 20:32:39.000000','LEFT','NEWS','QUESTION9','RIGHT'),(14,'END','2023-10-04 20:32:39.000000','LEFT','NEWS','QUESTION10','RIGHT'),(15,'END','2023-10-04 20:32:40.000000','LEFT','NEWS','QUESTION11','RIGHT'),(16,'END','2023-10-04 20:32:40.000000','LEFT','NEWS','QUESTION12','RIGHT'),(17,'END','2023-10-04 20:32:40.000000','LEFT','NEWS','QUESTION13','RIGHT'),(18,'END','2023-10-04 20:32:41.000000','LEFT','NEWS','QUESTION14','RIGHT'),(19,'END','2023-10-04 20:32:41.000000','LEFT','NEWS','QUESTION15','RIGHT');
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_member`
--

DROP TABLE IF EXISTS `balance_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_member` (
  `pk_balance_idx` bigint(20) NOT NULL,
  `pk_member_idx` bigint(20) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `select_answer` varchar(255) DEFAULT NULL,
  `balance_idx` bigint(20) DEFAULT NULL,
  `member_idx` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`pk_balance_idx`,`pk_member_idx`),
  KEY `FK4jk5votpjk00xalsin204yrnx` (`balance_idx`),
  KEY `FK8l0i4yxglqs43pxo9r5mwwyt6` (`member_idx`),
  CONSTRAINT `FK4jk5votpjk00xalsin204yrnx` FOREIGN KEY (`balance_idx`) REFERENCES `balance` (`idx`),
  CONSTRAINT `FK8l0i4yxglqs43pxo9r5mwwyt6` FOREIGN KEY (`member_idx`) REFERENCES `member` (`member_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_member`
--

LOCK TABLES `balance_member` WRITE;
/*!40000 ALTER TABLE `balance_member` DISABLE KEYS */;
INSERT INTO `balance_member` VALUES (1,3,'2023-10-03 06:44:30.435808','LEFT',1,3),(1,6,'2023-10-03 13:08:17.410569','LEFT',1,6),(1,9,'2023-10-04 03:46:52.082303','LEFT',1,9),(1,14,'2023-10-04 17:00:37.940238','RIGHT',1,14),(1,30,'2023-10-04 11:25:49.250232','LEFT',1,30),(1,64,'2023-10-05 06:52:32.160745','RIGHT',1,64),(1,86,'2023-10-06 04:17:06.909051','LEFT',1,86),(2,6,'2023-10-05 16:26:58.161645','RIGHT',2,6),(2,9,'2023-10-05 17:21:07.150991','LEFT',2,9),(2,30,'2023-10-06 04:17:33.784017','RIGHT',2,30),(2,86,'2023-10-06 04:17:09.071410','LEFT',2,86),(3,3,'2023-10-04 15:27:15.651952','RIGHT',3,3),(3,6,'2023-10-05 16:27:00.297967','LEFT',3,6),(3,9,'2023-10-05 18:00:02.650624','LEFT',3,9),(3,30,'2023-10-05 01:22:17.916245','LEFT',3,30),(3,64,'2023-10-05 06:52:29.612018','LEFT',3,64),(3,84,'2023-10-06 01:33:09.246942','RIGHT',3,84),(3,86,'2023-10-06 04:17:00.931895','RIGHT',3,86);
/*!40000 ALTER TABLE `balance_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge`
--

DROP TABLE IF EXISTS `challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenge` (
  `challenge_idx` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_category` varchar(255) DEFAULT NULL,
  `challenge_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`challenge_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge`
--

LOCK TABLES `challenge` WRITE;
/*!40000 ALTER TABLE `challenge` DISABLE KEYS */;
INSERT INTO `challenge` VALUES (1,'집안일','빨래'),(2,'집안일','청소'),(3,'집안일','설거지'),(4,'집안일','애완동물케어'),(6,'공부','수학 공부'),(7,'공부','영어 공부'),(8,'공부','사회 공부'),(9,'공부','국어 공부'),(10,'습관','일어나서 이불개기'),(11,'습관','아침 인사드리기'),(12,'효도','부모님 안아드리기'),(13,'효도','부모님에게 사랑한다하기');
/*!40000 ALTER TABLE `challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `children`
--

DROP TABLE IF EXISTS `children`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `children` (
  `pk_children_uuid` varchar(255) NOT NULL,
  `pk_parent_uuid` varchar(255) NOT NULL,
  `child_idx` bigint(20) DEFAULT NULL,
  `parent_idx` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`pk_children_uuid`,`pk_parent_uuid`),
  KEY `FKsncymevswryfebhyc33j97b4s` (`child_idx`),
  KEY `FKo23b0b01ucvmlpaea9omhxas9` (`parent_idx`),
  CONSTRAINT `FKo23b0b01ucvmlpaea9omhxas9` FOREIGN KEY (`parent_idx`) REFERENCES `member` (`member_idx`),
  CONSTRAINT `FKsncymevswryfebhyc33j97b4s` FOREIGN KEY (`child_idx`) REFERENCES `member` (`member_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `children`
--

LOCK TABLES `children` WRITE;
/*!40000 ALTER TABLE `children` DISABLE KEYS */;
INSERT INTO `children` VALUES ('468899cd-8803-4e4e-b346-9bd84f694e1f','97198fc5-ef14-4cde-b75c-cd6a712afca1',6,61),('82926a27-1855-4fa3-b2e5-4e15e6fa4b12','6044682e-f00c-4d48-b51d-84b0db999653',3,7),('d3a58e6c-14d7-4b3a-b58f-982aafc9836b','6044682e-f00c-4d48-b51d-84b0db999653',9,7),('d54780e5-63d0-4675-900c-c2070a654705','ed9bd4fa-bb87-4985-b68b-1d8af5ab0e38',64,31),('dcd9f2f3-8eec-41eb-b643-60a3b1115d45','6044682e-f00c-4d48-b51d-84b0db999653',30,7),('f8ac3865-f95f-4149-9343-1c7580e33649','d25d3010-a0f3-4975-8458-08c55840e822',76,74);
/*!40000 ALTER TABLE `children` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2023-09-22 05:39:51.508885','1','첫 밸런스 게임입니다!',1,'[{\"added\": {}}]',8,1),(2,'2023-09-22 05:49:39.379754','1','[ㅇㅇㄹㄴ] ㄴㅇㄹㄴㅇㄹ]',1,'[{\"added\": {}}]',9,1),(3,'2023-09-22 05:49:46.814175','1','[ㅇㅇㄹㄴ] ㄴㅇㄹㄴㅇㄹ]',3,'',9,1),(4,'2023-09-27 01:48:34.479940','1','[집안일] 애완동물케어]',1,'[{\"added\": {}}]',9,1),(5,'2023-09-27 01:49:17.383114','2','[집안일] 빨래]',1,'[{\"added\": {}}]',9,1),(6,'2023-09-27 01:49:26.996312','3','[집안일] 청소]',1,'[{\"added\": {}}]',9,1),(7,'2023-09-27 01:49:35.422106','4','[집안일] 설거지]',1,'[{\"added\": {}}]',9,1),(8,'2023-09-28 06:42:45.130224','1','[집안일] 애완동물케어]',1,'[{\"added\": {}}]',9,1),(9,'2023-09-28 06:42:58.896634','2','[집안일] 빨래]',1,'[{\"added\": {}}]',9,1),(10,'2023-09-28 06:43:00.509002','1','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(11,'2023-09-28 06:43:09.025937','3','[집안일] 청소]',1,'[{\"added\": {}}]',9,1),(12,'2023-09-28 06:43:16.861546','4','[집안일] 설거지]',1,'[{\"added\": {}}]',9,1),(13,'2023-09-28 07:24:22.553536','1','[집안일] 설거지]',1,'[{\"added\": {}}]',9,1),(14,'2023-09-28 07:24:37.561775','1','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(15,'2023-09-28 09:08:58.789207','1','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(16,'2023-09-28 09:21:08.681963','1','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(17,'2023-09-28 11:55:41.776108','1','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(18,'2023-09-29 04:57:58.656784','1','[집안일] 설거지]',1,'[{\"added\": {}}]',9,1),(19,'2023-09-29 06:44:22.129292','4','asdf',1,'[{\"added\": {}}]',8,1),(20,'2023-09-29 06:44:30.667790','5','asdf',1,'[{\"added\": {}}]',8,1),(21,'2023-09-29 06:44:40.729301','6','asdf',1,'[{\"added\": {}}]',8,1),(22,'2023-09-29 06:44:50.307715','7','asfdfdas',1,'[{\"added\": {}}]',8,1),(23,'2023-09-29 06:44:55.480285','8','asdffasd',1,'[{\"added\": {}}]',8,1),(24,'2023-09-29 06:45:00.248686','9','fasdsfad',1,'[{\"added\": {}}]',8,1),(25,'2023-09-29 06:45:07.479590','10','asdffasd',1,'[{\"added\": {}}]',8,1),(26,'2023-09-29 06:45:37.176250','11','asdf',1,'[{\"added\": {}}]',8,1),(27,'2023-09-29 06:45:45.297999','12','asdf',1,'[{\"added\": {}}]',8,1),(28,'2023-09-29 06:45:53.107655','13','fasdsfad',1,'[{\"added\": {}}]',8,1),(29,'2023-09-29 06:45:59.874320','14','asfdfdas',1,'[{\"added\": {}}]',8,1),(30,'2023-09-29 06:46:19.420208','15','asdffasd',1,'[{\"added\": {}}]',8,1),(31,'2023-09-29 06:46:42.062160','16','asfdfdas',1,'[{\"added\": {}}]',8,1),(32,'2023-09-29 06:46:48.724684','17','asdffasd',1,'[{\"added\": {}}]',8,1),(33,'2023-09-29 06:55:24.662739','18','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(34,'2023-09-29 12:40:24.969856','1','asdfa',1,'[{\"added\": {}}]',8,1),(35,'2023-09-29 12:41:17.997925','2','asdf',1,'[{\"added\": {}}]',8,1),(36,'2023-09-29 12:41:23.906313','3','asdf',1,'[{\"added\": {}}]',8,1),(37,'2023-09-29 12:47:23.645693','1','afsd',1,'[{\"added\": {}}]',8,1),(38,'2023-09-29 12:50:08.507142','2','asdf',1,'[{\"added\": {}}]',8,1),(39,'2023-09-29 12:52:37.748755','3','asdf',1,'[{\"added\": {}}]',8,1),(40,'2023-09-29 13:09:45.437296','4','asdf',1,'[{\"added\": {}}]',8,1),(41,'2023-09-30 04:44:17.709586','1','[집안일] 설거지]',1,'[{\"added\": {}}]',9,1),(42,'2023-09-30 07:57:16.697655','2','[집안일] 애완동물케어]',1,'[{\"added\": {}}]',9,1),(43,'2023-09-30 07:57:34.671672','3','[집안일] 빨래]',1,'[{\"added\": {}}]',9,1),(44,'2023-09-30 07:57:40.897213','4','[집안일] 청소]',1,'[{\"added\": {}}]',9,1),(45,'2023-09-30 09:13:38.178998','1','[집안일] 애완동물케어]',1,'[{\"added\": {}}]',9,1),(46,'2023-09-30 09:13:47.152784','2','[집안일] 빨래]',1,'[{\"added\": {}}]',9,1),(47,'2023-09-30 09:13:55.096800','3','[집안일] 청소]',1,'[{\"added\": {}}]',9,1),(48,'2023-09-30 09:14:01.269647','4','[집안일] 설거지]',1,'[{\"added\": {}}]',9,1),(49,'2023-09-30 09:28:05.781968','1','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(50,'2023-09-30 09:35:06.415617','2','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(51,'2023-09-30 10:05:11.262183','1','콩불은 맜있나요?',1,'[{\"added\": {}}]',8,1),(52,'2023-09-30 10:05:19.053137','2','asdffasd',1,'[{\"added\": {}}]',8,1),(53,'2023-09-30 10:05:26.446719','3','asfdfdas',1,'[{\"added\": {}}]',8,1),(54,'2023-09-30 10:07:08.609733','4','asdf',1,'[{\"added\": {}}]',8,1),(55,'2023-09-30 10:13:11.660655','1','[집안일] 빨래]',1,'[{\"added\": {}}]',9,1),(56,'2023-09-30 10:13:18.215655','2','[집안일] 청소]',1,'[{\"added\": {}}]',9,1),(57,'2023-09-30 10:13:25.406788','3','[집안일] 설거지]',1,'[{\"added\": {}}]',9,1),(58,'2023-10-02 11:45:38.128258','13','[사랑해의 영어?] I love you]',1,'[{\"added\": {}}]',10,1),(59,'2023-10-04 04:40:55.168656','14','[중국 인민은행이 ‘이것’을 또 인하했다. 은행이 고객에게 받은 예금 중 중앙은행에 의무적으로 예치해야 하는 비율인 이것은?] 3]',1,'[{\"added\": {}}]',10,1),(60,'2023-10-04 04:41:20.133073','15','[생산유발효과가 커 관광산업의 새 영역으로 주목받는 네 분야를 ‘마이스(MICE)’라고 한다. MICE와 거리가 먼 것은?] 4]',1,'[{\"added\": {}}]',10,1),(61,'2023-10-04 04:41:55.011408','16','[이자를 계산할 때 원금에 대한 이자뿐 아니라 이자에 대한 이자도 함께 계산하는 방식을 무엇이라 할까?] 2]',1,'[{\"added\": {}}]',10,1),(62,'2023-10-04 04:42:31.486571','17','[강력한 경쟁자가 등장했을 때 기존 기업들의 경쟁력이 오히려 강해지는 현상을 가리키는 용어는?] 1]',1,'[{\"added\": {}}]',10,1),(63,'2023-10-04 04:42:57.138078','18','[주식 한 주당 가격이 너무 비싸졌을 때 활발한 거래를 유도하기 위해 상장사가 단행하는 조치로 가장 적절한 것은?] 4]',1,'[{\"added\": {}}]',10,1),(64,'2023-10-04 04:43:21.385960','19','[다음 중 주요 국가와 기업의 신용등급을 매겨 발표하는 ‘신용평가 회사’에 속하는 기업은?] 3]',1,'[{\"added\": {}}]',10,1),(65,'2023-10-04 04:43:49.722861','20','[‘일대일로’ 전략을 주도한 정치 지도자로 가장 적절한 사람은?] 1]',1,'[{\"added\": {}}]',10,1),(66,'2023-10-04 04:44:23.190651','21','[물가상승률이 통제 불가능 수준으로 치솟은 상황을 말한다. 방만한 경제정책이 주된 원인으로 작용하는 이것은?] 1]',1,'[{\"added\": {}}]',10,1),(67,'2023-10-04 04:44:50.089917','13','[사랑해의 영어?] 1]',3,'',10,1),(68,'2023-10-04 04:44:53.489300','12','[question12] 1]',3,'',10,1),(69,'2023-10-04 04:44:56.640254','11','[question11] 1]',3,'',10,1),(70,'2023-10-04 04:45:00.272859','10','[question10] 1]',3,'',10,1),(71,'2023-10-04 04:45:03.539176','9','[question9] 1]',3,'',10,1),(72,'2023-10-04 04:45:07.651017','1','[question1] 1]',3,'',10,1),(73,'2023-10-04 04:45:11.047245','2','[question2] 1]',3,'',10,1),(74,'2023-10-04 04:45:14.539419','3','[question3] 1]',3,'',10,1),(75,'2023-10-04 04:45:17.755436','8','[question8] 1]',3,'',10,1),(76,'2023-10-04 04:45:20.246572','7','[question7] 1]',3,'',10,1),(77,'2023-10-04 04:45:22.956874','6','[question6] 1]',3,'',10,1),(78,'2023-10-04 04:45:25.391278','5','[question5] 1]',3,'',10,1),(79,'2023-10-04 04:45:27.890051','4','[question4] 1]',3,'',10,1),(80,'2023-10-04 04:46:02.260543','22','[관광지의 수용 한계를 넘어서는 많은 여행객이 몰려들어 발생하는 지역 내 문제를 뜻하는 말은?] 2]',1,'[{\"added\": {}}]',10,1),(81,'2023-10-04 04:46:22.658064','23','[주류, 담배, 도박, 경마 등과 같이 사회에 부정적인 영향을 주는 것들에 부과하는 세금을 가리키는 용어는?] 1]',1,'[{\"added\": {}}]',10,1),(82,'2023-10-04 04:47:00.430334','24','[기업의 무리한 인수합병(M&A)이 초래할 수 있는 부정적인 상황 중 하나로 볼 수 있는 것은 무엇인가?] 3]',1,'[{\"added\": {}}]',10,1),(83,'2023-10-04 04:47:27.277366','25','[특허가 만료된 오리지널 바이오의약품을 복제해 같은 품질로 만든 의약품으로, 저렴한 가격이 강점인 이것은?] 2]',1,'[{\"added\": {}}]',10,1),(84,'2023-10-04 04:47:49.934919','26','[‘이것’ 중에서 실업자가 차지하는 비율이 실업률이다. 이것에 들어갈 말은?] 1]',1,'[{\"added\": {}}]',10,1),(85,'2023-10-04 04:48:10.574010','27','[다음 중 ‘영끌’을 막기 위한 대출 규제에 활용되는 지표는?] 4]',1,'[{\"added\": {}}]',10,1),(86,'2023-10-04 04:48:29.369653','28','[수출 감소 폭보다 수입 감소 폭이 더 커진 데 기인해 경상수지가 흑자를 기록할 때 쓰는 표현은?] 4]',1,'[{\"added\": {}}]',10,1),(87,'2023-10-04 04:48:48.900848','29','[‘위고비’를 만든 덴마크 제약사로, 최근 루이비통모에헤네시(LVMH)를 제치고 유럽 증시 시가총액 1위에 오른 이 회사는?] 2]',1,'[{\"added\": {}}]',10,1),(88,'2023-10-04 04:49:13.547863','30','[인플레이션을 측정하는 주요 지표 중 하나인 ‘소비자물가지수’를 가리키는 약어는?] 1]',1,'[{\"added\": {}}]',10,1),(89,'2023-10-04 04:49:37.116046','31','[나라 살림의 건전성 지표가 일정 수준을 지켜나가도록 관리하는 규범을 뜻하는 용어는?] 3]',1,'[{\"added\": {}}]',10,1),(90,'2023-10-04 04:50:25.187135','32','[빚을 얻어 지렛대 삼아 투자함으로써 실질적 수익률을 극대화하는 전략을 가리키는 말은?] 2]',1,'[{\"added\": {}}]',10,1),(91,'2023-10-04 04:50:49.103215','33','[러시아·우크라이나 전쟁 이후 우크라이나산 곡물을 안전하게 수출하기 위해 맺어졌지만 지난 7월 러시아가 거부한 이것은?] 3]',1,'[{\"added\": {}}]',10,1),(92,'2023-10-04 04:51:06.236040','34','[기업이 발행하는 여러 종류의 채권 중 해당 업체 주식으로 바꿀 수 있는 권리가 부여된 것을 고르면?] 1]',1,'[{\"added\": {}}]',10,1),(93,'2023-10-04 04:51:20.842604','35','[소비자가 의도치 않게 물건을 사거나 이용료를 결제하게끔 서비스를 교묘하게 디자인하는 것을 뜻하는 말은?] 2]',1,'[{\"added\": {}}]',10,1),(94,'2023-10-04 04:51:47.350156','36','[한국은행이 기준금리를 다섯 차례 연속 동결했다. 현재 국내 기준금리는 얼마일까?] 3]',1,'[{\"added\": {}}]',10,1),(95,'2023-10-04 04:52:06.987680','37','[기업 실적에 상관없이 온라인 커뮤니티와 SNS를 통해 입소문을 타면서 개인투자자가 몰리는 주식을 뜻하는 말은?] 1]',1,'[{\"added\": {}}]',10,1),(96,'2023-10-04 04:52:26.721464','38','[‘모디노믹스’ ‘뉴델리’ ‘루피’ ‘센섹스지수’에서 연상되는 나라는?] 3]',1,'[{\"added\": {}}]',10,1),(97,'2023-10-04 04:52:54.287797','39','[정부 지출을 늘리면 오히려 민간투자를 위축시킬 수 있다는 내용의 이론은?] 2]',1,'[{\"added\": {}}]',10,1),(98,'2023-10-04 04:53:13.090124','40','[새로 주식을 발행하고 기존 주주나 새 주주에게 판매해 기업 자본금을 늘리는 방식을 일컫는 말은?] 2]',1,'[{\"added\": {}}]',10,1),(99,'2023-10-04 04:53:32.533418','41','[증시에서 재무구조가 탄탄한 ‘대형 우량주’를 가리키는 말은?] 3]',1,'[{\"added\": {}}]',10,1),(100,'2023-10-04 04:53:50.761129','42','[브라질, 러시아, 인도, 중국, 남아프리카공화국 등이 참여하고 있는 국제 협의체는?] 3]',1,'[{\"added\": {}}]',10,1),(101,'2023-10-04 04:54:11.752363','43','[공유 오피스 기업인 ‘이곳’이 경영 위기 끝에 뉴욕증시에서 상장폐지 수순을 밟고 있다. 한때 세계적 유니콘이던 이 회사는?] 4]',1,'[{\"added\": {}}]',10,1),(102,'2023-10-05 18:09:29.812669','4','[집안일] 애완동물케어]',1,'[{\"added\": {}}]',9,1),(103,'2023-10-05 18:09:55.730168','5','[공부] 국어공부]',1,'[{\"added\": {}}]',9,1),(104,'2023-10-05 18:10:06.956770','6','[공부] 수학 공부]',1,'[{\"added\": {}}]',9,1),(105,'2023-10-05 18:10:16.991167','7','[공부] 영어 공부]',1,'[{\"added\": {}}]',9,1),(106,'2023-10-05 18:10:28.222840','8','[공부] 사회 공부]',1,'[{\"added\": {}}]',9,1),(107,'2023-10-05 18:10:47.060456','5','[공부] 국어공부]',3,'',9,1),(108,'2023-10-05 18:10:57.130047','9','[공부] 국어 공부]',1,'[{\"added\": {}}]',9,1),(109,'2023-10-05 18:11:11.776363','10','[습관] 일어나서 이불개기]',1,'[{\"added\": {}}]',9,1),(110,'2023-10-05 18:11:23.353005','11','[습관] 아침 인사드리기]',1,'[{\"added\": {}}]',9,1),(111,'2023-10-05 18:11:32.690516','12','[효도] 부모님 안아드리기]',1,'[{\"added\": {}}]',9,1),(112,'2023-10-05 18:11:41.380180','13','[효도] 부모님에게 사랑한다하기]',1,'[{\"added\": {}}]',9,1),(113,'2023-10-06 00:05:13.500805','20','10000원을 갑자기 받았을 때 저축할껀가요?',1,'[{\"added\": {}}]',8,1),(115,'2023-10-06 00:05:45.392490','20','10000원을 갑자기 받았을 때 저축할껀가요?',3,'',8,1),(116,'2023-10-06 00:05:59.092459','2','10000원을 갑자기 받았을 때 저축할껀가요?',2,'[{\"changed\": {\"fields\": [\"Balance left answer\", \"Balance question\", \"Balance right answer\"]}}]',8,1),(117,'2023-10-06 00:06:27.066814','3','10000원을 갑자기 받았을 때 저축할껀가요?',2,'[{\"changed\": {\"fields\": [\"Balance left answer\", \"Balance question\", \"Balance right answer\"]}}]',8,1),(118,'2023-10-06 00:07:14.514084','3','만약 100만원이 주어진다면 주식? or 저축',2,'[{\"changed\": {\"fields\": [\"Balance left answer\", \"Balance question\", \"Balance right answer\"]}}]',8,1),(119,'2023-10-06 00:07:18.941932','4','asdf',3,'',8,1),(121,'2023-10-06 00:08:41.154587','1','돈이 갑자기 필요할 떄 졸라서 용돈? or 집안일?',2,'[{\"changed\": {\"fields\": [\"Balance left answer\", \"Balance question\", \"Balance right answer\"]}}]',8,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(8,'mwonimoney','balance'),(9,'mwonimoney','challenge'),(10,'mwonimoney','quiz'),(7,'mwonimoney','test'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2023-09-22 04:40:11.314667'),(2,'auth','0001_initial','2023-09-22 04:40:11.827279'),(3,'admin','0001_initial','2023-09-22 04:40:11.971905'),(4,'admin','0002_logentry_remove_auto_add','2023-09-22 04:40:11.995309'),(5,'admin','0003_logentry_add_action_flag_choices','2023-09-22 04:40:12.017334'),(6,'contenttypes','0002_remove_content_type_name','2023-09-22 04:40:12.108682'),(7,'auth','0002_alter_permission_name_max_length','2023-09-22 04:40:12.157522'),(8,'auth','0003_alter_user_email_max_length','2023-09-22 04:40:12.196187'),(9,'auth','0004_alter_user_username_opts','2023-09-22 04:40:12.220490'),(10,'auth','0005_alter_user_last_login_null','2023-09-22 04:40:12.265722'),(11,'auth','0006_require_contenttypes_0002','2023-09-22 04:40:12.284550'),(12,'auth','0007_alter_validators_add_error_messages','2023-09-22 04:40:12.303491'),(13,'auth','0008_alter_user_username_max_length','2023-09-22 04:40:12.340859'),(14,'auth','0009_alter_user_last_name_max_length','2023-09-22 04:40:12.381110'),(15,'auth','0010_alter_group_name_max_length','2023-09-22 04:40:12.418589'),(16,'auth','0011_update_proxy_permissions','2023-09-22 04:40:12.466794'),(17,'auth','0012_alter_user_first_name_max_length','2023-09-22 04:40:12.505096'),(18,'mwonimoney','0001_initial','2023-09-22 04:40:12.524185'),(19,'mwonimoney','0002_alter_test_options','2023-09-22 04:40:12.550018'),(20,'sessions','0001_initial','2023-09-22 04:40:12.620965');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('6nfbhed80riqudbqsz4wrr95nfw61zn2','.eJxVjEEOwiAQRe_C2hCHEQZcuvcMBGaoVA1NSrsy3l2bdKHb_977LxXTutS49jLHUdRZgTr8bjnxo7QNyD2126R5ass8Zr0peqddXycpz8vu_h3U1Ou3xmANBC4SyAtiJp8yk0GXjCVGI4wegY7k7OChAAwSfHDFCYiQO6n3B8iWNzA:1qm89Q:EGtsIcxKLNIchS_N-t5PDHL7_QAJuUCyJWF7wcb822I','2023-10-13 07:43:04.918724'),('pzgizg5u9jgqamlg6vf0nthx7pylndkf','.eJxVjEEOwiAQRe_C2hCHEQZcuvcMBGaoVA1NSrsy3l2bdKHb_977LxXTutS49jLHUdRZgTr8bjnxo7QNyD2126R5ass8Zr0peqddXycpz8vu_h3U1Ou3xmANBC4SyAtiJp8yk0GXjCVGI4wegY7k7OChAAwSfHDFCYiQO6n3B8iWNzA:1qlJOO:rjjzMxrq0ww_gliNRbbscX2wb1AqNv7v_uSGAGsoIrk','2023-10-11 01:31:08.135122'),('u9dfst0fuq2vtu6uonug83k5oebw5p3i','.eJxVjEEOwiAQRe_C2hCHEQZcuvcMBGaoVA1NSrsy3l2bdKHb_977LxXTutS49jLHUdRZgTr8bjnxo7QNyD2126R5ass8Zr0peqddXycpz8vu_h3U1Ou3xmANBC4SyAtiJp8yk0GXjCVGI4wegY7k7OChAAwSfHDFCYiQO6n3B8iWNzA:1qoaEF:OMtZCjNMuyZK2R-4sxtpf7diqhYWg2LoksryZMpQqPw','2023-10-20 02:06:11.539569'),('vw7w7l31csfu2nrsnw03z6jle72r8rwb','.eJxVjEEOwiAQRe_C2hCHEQZcuvcMBGaoVA1NSrsy3l2bdKHb_977LxXTutS49jLHUdRZgTr8bjnxo7QNyD2126R5ass8Zr0peqddXycpz8vu_h3U1Ou3xmANBC4SyAtiJp8yk0GXjCVGI4wegY7k7OChAAwSfHDFCYiQO6n3B8iWNzA:1qoFuB:CEwF8x7SpU8tz3v9XngdA2um8zZeeBLrPIaNKoQwjCA','2023-10-19 04:24:07.593340');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fin_account`
--

DROP TABLE IF EXISTS `fin_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fin_account` (
  `fin_account_idx` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) DEFAULT NULL,
  `fin_account_number` varchar(255) DEFAULT NULL,
  `fin_account_status` varchar(255) DEFAULT NULL,
  `fin_account_type` varchar(255) DEFAULT NULL,
  `member_idx` bigint(20) DEFAULT NULL,
  `fin_account_register_number` varchar(255) DEFAULT NULL,
  `fin_account_fin_acno` varchar(255) DEFAULT NULL,
  `fin_account_remain` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`fin_account_idx`),
  KEY `FKj31ukn9mq9rbi9rckyab73w7j` (`member_idx`),
  CONSTRAINT `FKj31ukn9mq9rbi9rckyab73w7j` FOREIGN KEY (`member_idx`) REFERENCES `member` (`member_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fin_account`
--

LOCK TABLES `fin_account` WRITE;
/*!40000 ALTER TABLE `fin_account` DISABLE KEYS */;
INSERT INTO `fin_account` VALUES (7,'2023-10-03 23:48:26.723061','{\r\n    12312312\r\n}','ACTIVATE','GENERAL',3,NULL,'00820100020640000000000016235',10300),(8,'2023-10-03 15:08:11.016047','351-0868-4688-53=','ACTIVATE','GENERAL',6,NULL,'00820100020640000000000016235',950000),(10,'2023-10-04 00:27:06.168482','123-123-123-123=','ACTIVATE','GENERAL',7,NULL,'00820100020640000000000016235',9700),(21,'2023-10-04 16:10:59.225500','dcd9f2f3-8eec-41eb-b643-60a3b1115d45','DEACTIVATE','SMALL',30,NULL,'dcd9f2f3-8eec-41eb-b643-60a3b1115d45',NULL),(22,'2023-10-04 16:51:08.265367','{\r\n	\"accountNumber\" : 123123123\r\n}','DEACTIVATE','GENERAL',30,NULL,'63a861c4-d4b6-41e2-9447-899f8320763d',0),(23,'2023-10-04 16:54:14.964464','{\r\n	\"accountNumber\" : 123123123\r\n}','ACTIVATE','GENERAL',30,NULL,'742e689c-6eea-43ee-97f9-f25a6302fb38',0),(24,'2023-10-04 12:32:39.966095',NULL,'DEACTIVATE','SMALL',6,NULL,NULL,0),(25,'2023-10-04 15:43:51.203682',NULL,'DEACTIVATE','SMALL',3,NULL,NULL,0),(26,'2023-10-05 00:56:20.074290','12345678910=','ACTIVATE','GENERAL',9,NULL,'00820100020640000000000016235',9999999),(27,'2023-10-05 01:00:46.808305','09876543210=','ACTIVATE','GENERAL',31,NULL,'00820100020640000000000016235',99895101),(28,'2023-10-05 03:10:55.587246',NULL,'DEACTIVATE','SMALL',6,NULL,NULL,0),(29,'2023-10-05 03:39:07.921008',NULL,'DEACTIVATE','SMALL',6,NULL,NULL,0),(30,'2023-10-05 03:39:07.921008','351-0868-4688-54=','ACTIVATE','GENERAL',64,NULL,'00820100020640000000000016233',51000),(31,'2023-10-05 04:01:05.478413','508-12-906207-8','ACTIVATE','GENERAL',74,NULL,'00820100020640000000000016235',9999900),(32,'2023-10-05 04:08:55.686101','507-126-546589-7','ACTIVATE','GENERAL',76,NULL,'00820100020640000000000016235',30100),(33,'2023-10-05 12:22:13.382521',NULL,'DEACTIVATE','SMALL',3,NULL,NULL,0),(34,'2023-10-05 13:26:24.798776',NULL,'DEACTIVATE','SMALL',6,NULL,NULL,0),(35,'2023-10-05 14:04:51.847141',NULL,'ACTIVATE','SMALL',6,NULL,NULL,15000),(36,'2023-10-05 14:08:02.258103',NULL,'ACTIVATE','SMALL',3,NULL,NULL,0),(37,'2023-10-06 00:28:37.995301',NULL,'ACTIVATE','SMALL',9,NULL,NULL,0);
/*!40000 ALTER TABLE `fin_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fin_account_transaction`
--

DROP TABLE IF EXISTS `fin_account_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fin_account_transaction` (
  `transaction_idx` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) DEFAULT NULL,
  `transaction_balance` int(11) DEFAULT NULL,
  `transaction_memo` varchar(255) DEFAULT NULL,
  `transaction_money` int(11) DEFAULT NULL,
  `transaction_time` datetime(6) DEFAULT NULL,
  `fin_account_idx` bigint(20) DEFAULT NULL,
  `fin_account_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`transaction_idx`),
  KEY `FKm4ncmyq1y96wyd7hx0slvey2a` (`fin_account_idx`),
  KEY `FKlapnub8yjksyny7bvcq0i1vo4` (`fin_account_id`),
  CONSTRAINT `FKlapnub8yjksyny7bvcq0i1vo4` FOREIGN KEY (`fin_account_id`) REFERENCES `fin_account` (`fin_account_idx`),
  CONSTRAINT `FKm4ncmyq1y96wyd7hx0slvey2a` FOREIGN KEY (`fin_account_idx`) REFERENCES `fin_account` (`fin_account_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fin_account_transaction`
--

LOCK TABLES `fin_account_transaction` WRITE;
/*!40000 ALTER TABLE `fin_account_transaction` DISABLE KEYS */;
INSERT INTO `fin_account_transaction` VALUES (1,'2023-10-04 00:23:57.000000',100000,'박기택',-500,'2023-10-04 00:23:25.000000',7,NULL),(3,NULL,123,'박기택`ㄴ',-123,NULL,10,NULL),(4,'2023-10-06 09:50:14.000000',-100,'김',51505,'2023-10-06 09:50:33.000000',10,NULL),(5,NULL,500000,'asdfasdfasdf',456456,NULL,10,NULL),(6,'2023-10-05 10:08:30.915696',9200,'챌린지 보상',-800,'2023-10-05 10:08:30.900734',27,NULL),(7,'2023-10-05 10:08:30.949604',10000,'00820100020640000000000016235800',800,'2023-10-05 10:08:30.901732',25,NULL),(8,'2023-10-05 10:12:38.561161',8500,'챌린지 보상',-700,'2023-10-05 10:12:38.561161',27,NULL),(9,'2023-10-05 10:12:38.572806',9200,'00820100020640000000000016235700',700,'2023-10-05 10:12:38.561161',33,NULL),(10,'2023-10-05 10:50:39.602853',7700,'챌린지 보상',-800,'2023-10-05 10:50:39.598865',27,NULL),(11,'2023-10-05 10:50:39.628228',10000799,'00820100020640000000000016235800',800,'2023-10-05 10:50:39.599862',33,NULL),(12,'2023-10-05 11:09:34.139915',99900000,'챌린지 보상',-100000,'2023-10-05 11:09:34.125912',27,NULL),(13,'2023-10-05 11:09:34.167880',10099999,'00820100020640000000000016235100000',100000,'2023-10-05 11:09:34.126946',26,NULL),(14,'2023-10-05 05:32:01.434367',99899100,'챌린지 보상',-900,'2023-10-05 05:32:01.427657',27,NULL),(15,'2023-10-05 05:32:01.452510',10000899,'00820100020640000000000016235900',900,'2023-10-05 05:32:01.428864',26,NULL),(16,'2023-10-05 13:05:12.657766',99898101,'챌린지 보상',-999,'2023-10-05 13:05:12.654530',27,NULL),(17,'2023-10-05 13:05:12.663338',10000998,'00820100020640000000000016235999',999,'2023-10-05 13:05:12.655686',26,NULL),(18,'2023-10-06 01:56:28.987990',9900000,'퀴즈 리워드',-100000,'2023-10-06 01:56:28.979020',10,NULL),(19,'2023-10-06 01:56:29.076782',121110,'00820100020640000000000016235100000',100000,'2023-10-06 01:56:28.984008',7,NULL),(20,'2023-10-06 02:02:23.609272',9800000,'퀴즈 리워드',-100000,'2023-10-06 02:02:23.601324',10,NULL),(21,'2023-10-06 02:02:23.631207',121110,'00820100020640000000000016235100000',100000,'2023-10-06 02:02:23.604281',7,NULL),(22,'2023-10-06 02:02:37.911707',9700000,'퀴즈 리워드',-100000,'2023-10-06 02:02:37.911707',10,NULL),(23,'2023-10-06 02:02:37.923680',121110,'00820100020640000000000016235100000',100000,'2023-10-06 02:02:37.911707',7,NULL),(24,'2023-10-06 02:10:19.959882',9900,'퀴즈 리워드',-100,'2023-10-06 02:10:19.952904',10,NULL),(25,'2023-10-06 02:10:19.986811',10100,'퀴즈 리워드',100,'2023-10-06 02:10:19.955892',7,NULL),(42,'2023-10-05 17:17:02.362551',99896101,'챌린지 보상',-2000,'2023-10-05 17:17:02.362285',27,NULL),(43,'2023-10-05 17:17:02.364368',10001999,'008201000206400000000000162352000',2000,'2023-10-05 17:17:02.362305',26,NULL),(58,'2023-10-06 02:38:11.982699',9800,'챌린지 보상',-100,'2023-10-06 02:38:11.968703',10,NULL),(59,'2023-10-06 02:38:12.013697',10200,'챌린지 보상',100,'2023-10-06 02:38:11.969703',7,NULL),(60,'2023-10-06 00:18:46.780292',9700,'퀴즈 리워드',-100,'2023-10-06 00:18:46.777003',10,NULL),(61,'2023-10-06 00:18:46.785842',10300,'퀴즈 리워드',100,'2023-10-06 00:18:46.778083',7,NULL),(62,'2023-10-06 00:28:53.395516',9999900,'챌린지 보상',-100,'2023-10-06 00:28:53.395232',31,NULL),(63,'2023-10-06 00:28:53.397170',30100,'챌린지 보상',100,'2023-10-06 00:28:53.395258',32,NULL),(64,'2023-10-06 02:08:59.162410',99895101,'챌린지 보상',-1000,'2023-10-06 02:08:59.159203',27,NULL),(65,'2023-10-06 02:08:59.168287',51000,'챌린지 보상',1000,'2023-10-06 02:08:59.160247',30,NULL);
/*!40000 ALTER TABLE `fin_account_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan` (
  `loan_idx` bigint(20) NOT NULL AUTO_INCREMENT,
  `loan_amount` int(11) DEFAULT NULL,
  `loan_borrower` bigint(20) DEFAULT NULL,
  `loan_content` varchar(255) DEFAULT NULL,
  `loan_deadline` datetime(6) DEFAULT NULL,
  `loan_lender` bigint(20) DEFAULT NULL,
  `loan_name` varchar(255) DEFAULT NULL,
  `loan_status` varchar(255) DEFAULT NULL,
  `loan_rate` double DEFAULT NULL,
  `loan_balance` int(11) DEFAULT NULL,
  PRIMARY KEY (`loan_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
INSERT INTO `loan` VALUES (3,8000,9,'대출깁미','2023-10-19 00:00:00.000000',31,'대출','PAID',0.3,0),(4,900,9,'ㅋㅋㅋㅋ','2023-10-18 00:00:00.000000',31,'걀걀걀','PAID',0.2,0),(5,800,9,'대출대출','2023-10-13 00:00:00.000000',31,'대출','PAID',0.6,0),(16,100,9,'ㅈㄷㄱㅈㄷㄱ','2023-10-19 00:00:00.000000',31,'ㅈㄷㄱ','PAID',0.9,0),(17,800,9,'ㅇㅎㅀ','2023-10-26 00:00:00.000000',31,'ㅀㅇㅎ','PAID',0.7,0),(18,1000,9,'sdfsdff','2023-10-26 00:00:00.000000',31,'vxvc','PAID',0.8,0),(19,1000,9,'dsfs','2023-10-26 00:00:00.000000',31,'dsfs','REJECTION',0.9,1000),(20,1500,9,'dfsfdsd','2023-10-26 00:00:00.000000',31,'sdfs','REJECTION',1,1500),(21,123,30,'123ㅁㄴㅇㄹ','2023-10-10 00:00:00.000000',7,'dbfkal','WATING',1,123),(22,123,3,'123','2023-10-04 00:00:00.000000',7,'taektori','APPROVAL',1,123),(24,1000,9,'sdf','2023-10-18 00:00:00.000000',31,'sdf','PAID',0.8,0),(25,10000,6,'엄마대출','2023-10-27 00:00:00.000000',61,'아껴써라','PAID',12,0),(26,800,9,'ddfgdfg','2023-10-31 00:00:00.000000',31,'dsdfdsf','PAID',0.8,0),(27,20000,6,'마라탕값','2023-10-13 00:00:00.000000',61,'아껴써라','APPROVAL',2,10000),(28,20000,82,'마라탕비','2023-10-10 00:00:00.000000',31,'아껴써라~','PAID',0.1,0),(29,1000,82,'ㄴㅇㄹㄴ','2023-10-10 00:00:00.000000',31,'ㄴㄹ','PAID',0.1,0),(30,10000,76,'사랑','2023-10-17 00:00:00.000000',74,'기택의 특별대출','APPROVAL',0.1,10000),(31,20000,82,'마라탕비','2023-10-13 00:00:00.000000',31,'아껴써라','PAID',0.1,0),(32,20000,82,'대출','2023-10-12 00:00:00.000000',31,'대출','PAID',0.1,0),(33,20000,64,'대출','2023-10-13 00:00:00.000000',31,'대출','PAID',0.1,0),(34,20000,64,'대출','2023-10-19 00:00:00.000000',31,'대출','PAID',0.2,0),(35,20000,64,'대출','2023-10-19 00:00:00.000000',31,'대출','PAID',0.2,0),(36,20000,64,'대출','2023-10-18 00:00:00.000000',31,'대출','PAID',0.2,0),(37,20000,64,'절약하거라','2023-10-07 00:00:00.000000',31,'대출','APPROVAL',0.1,3500),(38,40000,64,'돈 잘 쓰거라','2023-10-12 00:00:00.000000',31,'대출','APPROVAL',0.1,26000),(39,10000,64,'잘 쓰거라','2023-10-06 00:00:00.000000',31,'대출','REJECTION',0.2,10000),(40,20000,64,'대출','2023-10-12 00:00:00.000000',31,'대출','PAID',0.1,0),(41,20000,64,'마라탕비','2023-10-13 00:00:00.000000',31,'아껴쓰거라','PAID',0.2,0);
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `dtype` varchar(31) NOT NULL,
  `member_idx` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) DEFAULT NULL,
  `fcmtoken` varchar(300) DEFAULT NULL,
  `member_birthday` varchar(255) DEFAULT NULL,
  `member_email` varchar(255) DEFAULT NULL,
  `member_role` varchar(255) DEFAULT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  `member_nickname` varchar(255) DEFAULT NULL,
  `member_social_id` varchar(255) DEFAULT NULL,
  `member_social_provider` varchar(255) DEFAULT NULL,
  `member_status` int(11) NOT NULL,
  `member_uuid` varchar(255) NOT NULL,
  `member_credit_score` int(11) DEFAULT NULL,
  `member_quiz_reward` int(11) DEFAULT NULL,
  `member_quiz_reward_remain` int(11) DEFAULT NULL,
  `smallaccount_goalmoney` int(11) DEFAULT NULL,
  `smallaccount_goal_name` varchar(255) DEFAULT NULL,
  `smallaccount_imagefilename` varchar(255) DEFAULT NULL,
  `smallaccount_saveratio` int(11) DEFAULT NULL,
  `balance_alarm` varchar(255) DEFAULT NULL,
  `challenge_alarm` varchar(255) DEFAULT NULL,
  `small_acount_alarm` varchar(255) DEFAULT NULL,
  `member_regular_allowance` int(11) DEFAULT NULL,
  `member_regular_allowance_day` int(11) DEFAULT NULL,
  PRIMARY KEY (`member_idx`),
  UNIQUE KEY `UK_tf30a0bikx3impl0p9s66bnu4` (`member_uuid`),
  UNIQUE KEY `UK_egbftod1lkyk9p76ly6tmcffp` (`member_social_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('Child',3,'2023-09-30 09:27:16.760864',NULL,'0000-00-00','taektree@naver.com','CHILD','박기택','박기택','3036788246','KAKAO',0,'82926a27-1855-4fa3-b2e5-4e15e6fa4b12',0,100,0,0,'','20231005140801_354781',12,NULL,NULL,NULL,10000,5),('Child',6,'2023-09-30 10:12:41.660741',NULL,'1997-03-20','J1@gmail.com','CHILD','김재이','재이','3041970473','KAKAO',1,'468899cd-8803-4e4e-b346-9bd84f694e1f',0,0,0,35000,'김동동','20231005140451_840889',3,NULL,NULL,NULL,50000,5),('Parent',7,'2023-09-30 10:17:52.304734',NULL,'0000-00-00','taekputer@gmail.com','PARENT','박기택','박기택','107191579559473502952','GOOGLE',0,'6044682e-f00c-4d48-b51d-84b0db999653',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Child',9,'2023-09-30 12:59:01.535998',NULL,'1998-08-09','leezi809@naver.com','CHILD','이지현','이지현','3039274977','KAKAO',0,'d3a58e6c-14d7-4b3a-b58f-982aafc9836b',0,500000,0,360000,'닌텐도','20231006002837_952906',10,NULL,NULL,NULL,0,1),('Parent',14,'2023-10-01 05:38:08.548350',NULL,'2015-01-23','w12456422@gmail.com','PARENT','Minjae Yun','Minjae Yun','106837470917207103837','GOOGLE',0,'c56a52cd-4992-4450-bce6-87aeffa1ee6d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Child',30,'2023-10-01 08:00:55.669748',NULL,'2015-05-14','tjdfkr011@naver.com','CHILD','조성락','조성락','3039249702','KAKAO',0,'dcd9f2f3-8eec-41eb-b643-60a3b1115d45',0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),('Parent',31,'2023-10-01 08:02:21.435699',NULL,'19980808','jiheon809@gmail.com','PARENT','이부모','jjj jj','117354652595046720752','GOOGLE',0,'ed9bd4fa-bb87-4985-b68b-1d8af5ab0e38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Guest',32,'2023-10-02 04:31:15.007027',NULL,'0000-00-00','taekputer@gmail.com','GUEST','taekto','taekto','3038638903','KAKAO',0,'021239cb-dba0-4503-9f57-5b0ca38343b9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Parent',61,'2023-10-03 10:49:32.165126',NULL,'1997-037-21','dobby1@gmail.com','PARENT','김재삼','Jae2 Kim','116747347744073571486','GOOGLE',0,'97198fc5-ef14-4cde-b75c-cd6a712afca1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','Y','Y',NULL,NULL),('Child',64,'2023-10-03 20:32:23.494829',NULL,'0000-00-00','w124564@naver.com','CHILD','윤민재','윤민재','3038140422','KAKAO',0,'d54780e5-63d0-4675-900c-c2070a654705',0,0,0,NULL,NULL,NULL,NULL,'Y','Y','Y',10000,15),('Parent',66,'2023-10-03 12:40:24.289749',NULL,'0000-00-00',NULL,'PARENT','MADEINUSA','MADEINUSA','3048377322','KAKAO',0,'9bb4b76c-b496-4fce-801b-b3dc83b50192',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','Y','Y',NULL,NULL),('Parent',68,'2023-10-03 16:31:55.637465',NULL,'0000-00-00','yllh325@gmail.com','PARENT','연제경','연제경','3048652279','KAKAO',0,'570cb317-00bd-4d34-9f5d-b5f8d36d2d58',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','Y','Y',NULL,NULL),('Child',71,'2023-10-04 13:57:25.869502',NULL,'0000-00-00',NULL,'CHILD','은성','은성','3050140997','KAKAO',0,'30c56709-8f71-4229-898a-aafef48375b3',0,0,0,NULL,NULL,NULL,NULL,'Y','Y','Y',0,0),('Parent',72,'2023-10-04 14:11:56.704693',NULL,'0000-00-00','aldms8960@naver.com','PARENT','최미은','최미은','3050133206','KAKAO',0,'2de3de32-9b8b-4b0f-affe-a8497fafafef',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','Y','Y',NULL,NULL),('Parent',74,'2023-10-05 04:00:41.153121',NULL,'1998-09-26','mytaekto@gmail.com','PARENT','박기택','박기택','101494761072998502234','GOOGLE',0,'d25d3010-a0f3-4975-8458-08c55840e822',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','Y','Y',NULL,NULL),('Child',76,'2023-10-05 04:08:36.176423',NULL,'2010-07-02','mieunchoi.dev@gmail.com','CHILD','최미은','최미은','118206097237748232345','GOOGLE',0,'f8ac3865-f95f-4149-9343-1c7580e33649',0,0,0,NULL,NULL,NULL,NULL,'Y','Y','Y',0,0),('Parent',78,'2023-10-05 05:03:21.226760',NULL,'0000-00-00','gyeong270@gmail.com','PARENT','김재이','김재이','100773904332907506874','GOOGLE',0,'d307b5c8-2c0d-4c4f-8d28-d047578da5ec',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','Y','Y',NULL,NULL),('Parent',80,'2023-10-05 08:40:35.891127',NULL,'0000-00-00',NULL,'PARENT','나건','나건','3051207023','KAKAO',0,'cbaadfdd-6bc4-4cd1-a6ac-8d2e4e009831',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','Y','Y',NULL,NULL),('Child',82,'2023-10-05 18:18:06.169673',NULL,'0000-00-00','45choi22@gmail.com','CHILD','최미은','최미은','105118841936789042558','GOOGLE',0,'08247c18-9e21-4728-aaa9-9a69ebbb65ce',0,0,0,NULL,NULL,NULL,NULL,'Y','Y','Y',0,0),('Child',84,'2023-10-06 01:32:37.843961',NULL,'0000-00-00','pgy1613@naver.com','CHILD','박지영','박지영','3052113463','KAKAO',0,'3392ec34-4a78-4250-8e99-8929dae46bba',0,0,0,NULL,NULL,NULL,NULL,'Y','Y','Y',0,0),('Child',86,'2023-10-06 04:15:25.505203',NULL,'0000-00-00','j010404@naver.com','CHILD','.','.','3052339821','KAKAO',0,'7ed559b8-a52b-45bd-b58e-0f47e63ec797',0,0,0,NULL,NULL,NULL,NULL,'Y','Y','Y',0,0);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_challenge`
--

DROP TABLE IF EXISTS `member_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_challenge` (
  `member_challenge_idx` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) DEFAULT NULL,
  `challenge_end_time` datetime(6) DEFAULT NULL,
  `challenge_memo` varchar(255) DEFAULT NULL,
  `challenge_reward` int(11) DEFAULT NULL,
  `challenge_status` int(11) DEFAULT NULL,
  `challenge_idx` int(11) DEFAULT NULL,
  `member_idx` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`member_challenge_idx`),
  KEY `FKbn7j6h6w4h6kt79tm2ilbbf23` (`challenge_idx`),
  KEY `FKcxf6e89cjx7puy95ncfqa4c5l` (`member_idx`),
  CONSTRAINT `FKbn7j6h6w4h6kt79tm2ilbbf23` FOREIGN KEY (`challenge_idx`) REFERENCES `challenge` (`challenge_idx`),
  CONSTRAINT `FKcxf6e89cjx7puy95ncfqa4c5l` FOREIGN KEY (`member_idx`) REFERENCES `member` (`member_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_challenge`
--

LOCK TABLES `member_challenge` WRITE;
/*!40000 ALTER TABLE `member_challenge` DISABLE KEYS */;
INSERT INTO `member_challenge` VALUES (107,'2023-10-04 10:48:16.434018','2023-10-24 00:00:00.000000','ㅁㄴㅇㄹ',1000,3,1,3),(122,'2023-10-05 12:43:18.678722','2023-10-12 00:00:00.000000','빨래 하기',500,2,1,30),(127,'2023-10-05 13:16:37.269391','2023-10-13 00:00:00.000000','빨래 널기',3000,2,1,6),(141,'2023-10-05 17:15:51.014687','2023-10-19 00:00:00.000000','ㅁㄴㅇㄹ',100,3,1,3),(147,'2023-10-06 00:28:26.614398','2023-10-11 00:00:00.000000','ㅁㄴㅇㄹ',100,3,4,76),(148,'2023-10-06 02:06:53.111731','2023-10-07 00:00:00.000000','설거지해주세요!',1000,3,3,64),(149,'2023-10-06 02:07:14.124169','2023-10-16 00:00:00.000000','수학익힘책 풀기',10000,4,6,64),(150,'2023-10-06 02:07:42.281231','2023-10-19 00:00:00.000000','10분 꽉 안기!',500,0,12,64);
/*!40000 ALTER TABLE `member_challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz` (
  `quiz_idx` bigint(20) NOT NULL AUTO_INCREMENT,
  `quiz_answer` varchar(255) DEFAULT NULL,
  `quiz_option1` varchar(255) DEFAULT NULL,
  `quiz_option2` varchar(255) DEFAULT NULL,
  `quiz_option3` varchar(255) DEFAULT NULL,
  `quiz_option4` varchar(255) DEFAULT NULL,
  `quiz_question` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`quiz_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
INSERT INTO `quiz` VALUES (14,'3','예대마진','재할인율','지급준비율','자기자본비율','중국 인민은행이 ‘이것’을 또 인하했다. 은행이 고객에게 받은 예금 중 중앙은행에 의무적으로 예치해야 하는 비율인 이것은?'),(15,'4','기업 회의','포상 관광','전시·박람회','어학연수','생산유발효과가 커 관광산업의 새 영역으로 주목받는 네 분야를 ‘마이스(MICE)’라고 한다. MICE와 거리가 먼 것은?'),(16,'2','단리','복리','고정금리','변동금리','이자를 계산할 때 원금에 대한 이자뿐 아니라 이자에 대한 이자도 함께 계산하는 방식을 무엇이라 할까?'),(17,'1','메기효과','기저효과','풍선효과','낙수효과','강력한 경쟁자가 등장했을 때 기존 기업들의 경쟁력이 오히려 강해지는 현상을 가리키는 용어는?'),(18,'4','우회상장','인적 분할','물적분할','액면분할','주식 한 주당 가격이 너무 비싸졌을 때 활발한 거래를 유도하기 위해 상장사가 단행하는 조치로 가장 적절한 것은?'),(19,'3','ARM','골드만삭스','무디스','버크셔 해서웨이','다음 중 주요 국가와 기업의 신용등급을 매겨 발표하는 ‘신용평가 회사’에 속하는 기업은?'),(20,'1','시진핑','조 바이든','기시다 후미오','리시 수낵','‘일대일로’ 전략을 주도한 정치 지도자로 가장 적절한 사람은?'),(21,'1','하이퍼인플레이션','스태그플레이션','카니벌라이제이션','젠트리피케이션','물가상승률이 통제 불가능 수준으로 치솟은 상황을 말한다. 방만한 경제정책이 주된 원인으로 작용하는 이것은?'),(22,'2','젠트리피케이션','오버투어리즘','유리천장','갈라파고스','관광지의 수용 한계를 넘어서는 많은 여행객이 몰려들어 발생하는 지역 내 문제를 뜻하는 말은?'),(23,'1','죄악세','준조세','간접세','역진세','주류, 담배, 도박, 경마 등과 같이 사회에 부정적인 영향을 주는 것들에 부과하는 세금을 가리키는 용어는?'),(24,'3','구축효과','피터팬증후군','승자의 저주','죄수의 딜레마','기업의 무리한 인수합병(M&A)이 초래할 수 있는 부정적인 상황 중 하나로 볼 수 있는 것은 무엇인가?'),(25,'2','미투 제품','바이오시밀러','카피캣','바이오매스','특허가 만료된 오리지널 바이오의약품을 복제해 같은 품질로 만든 의약품으로, 저렴한 가격이 강점인 이것은?'),(26,'1','경제활동인구','비경제활동인구','생산가능인구','정답 없음','‘이것’ 중에서 실업자가 차지하는 비율이 실업률이다. 이것에 들어갈 말은?'),(27,'4','ROE','PSR','BPS','DSR','다음 중 ‘영끌’을 막기 위한 대출 규제에 활용되는 지표는?'),(28,'4','역자산효과','기저효과','쌍둥이 흑자','불황형 흑자','수출 감소 폭보다 수입 감소 폭이 더 커진 데 기인해 경상수지가 흑자를 기록할 때 쓰는 표현은?'),(29,'2','일라이릴리','노보 노디스크','화이자','존슨앤드존슨','‘위고비’를 만든 덴마크 제약사로, 최근 루이비통모에헤네시(LVMH)를 제치고 유럽 증시 시가총액 1위에 오른 이 회사는?'),(30,'1','CPI','CSI','PPI','PCE','인플레이션을 측정하는 주요 지표 중 하나인 ‘소비자물가지수’를 가리키는 약어는?'),(31,'3','일몰제','하인리히 법칙','재정준칙','포지티브 규제','나라 살림의 건전성 지표가 일정 수준을 지켜나가도록 관리하는 규범을 뜻하는 용어는?'),(32,'2','구축 효과','레버리지 효과','피구 효과','베블런 효과','빚을 얻어 지렛대 삼아 투자함으로써 실질적 수익률을 극대화하는 전략을 가리키는 말은?'),(33,'3','을사늑약','제네바협약','흑해곡물협정','흑해곡물협정','러시아·우크라이나 전쟁 이후 우크라이나산 곡물을 안전하게 수출하기 위해 맺어졌지만 지난 7월 러시아가 거부한 이것은?'),(34,'1','전환사채','영구채','기업어음','자산유동화증권','기업이 발행하는 여러 종류의 채권 중 해당 업체 주식으로 바꿀 수 있는 권리가 부여된 것을 고르면?'),(35,'2','그린백','다크패턴','레몬마켓','화이트리스트','소비자가 의도치 않게 물건을 사거나 이용료를 결제하게끔 서비스를 교묘하게 디자인하는 것을 뜻하는 말은?'),(36,'3','연 3.0%','연 3.25%','연 3.5%','연 3.75%','한국은행이 기준금리를 다섯 차례 연속 동결했다. 현재 국내 기준금리는 얼마일까?'),(37,'1','밈 주식','황제주','블루칩','자사주','기업 실적에 상관없이 온라인 커뮤니티와 SNS를 통해 입소문을 타면서 개인투자자가 몰리는 주식을 뜻하는 말은?'),(38,'3','브라질','러시아','인도','뉴질랜드','‘모디노믹스’ ‘뉴델리’ ‘루피’ ‘센섹스지수’에서 연상되는 나라는?'),(39,'2','풍선 효과','구축 효과','승수 효과','자산 효과','정부 지출을 늘리면 오히려 민간투자를 위축시킬 수 있다는 내용의 이론은?'),(40,'2','무상증자','유상증자','직상장','우회상장','새로 주식을 발행하고 기존 주주나 새 주주에게 판매해 기업 자본금을 늘리는 방식을 일컫는 말은?'),(41,'3','스톡옵션','자사주','블루칩','밸류에이션','증시에서 재무구조가 탄탄한 ‘대형 우량주’를 가리키는 말은?'),(42,'3','G7','OPEC+','브릭스','칩4','브라질, 러시아, 인도, 중국, 남아프리카공화국 등이 참여하고 있는 국제 협의체는?'),(43,'4','우버','스페이스X','알리바바','위워크','공유 오피스 기업인 ‘이곳’이 경영 위기 끝에 뉴욕증시에서 상장폐지 수순을 밟고 있다. 한때 세계적 유니콘이던 이 회사는?');
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_history`
--

DROP TABLE IF EXISTS `quiz_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_history` (
  `quiz_history_idx` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) DEFAULT NULL,
  `member_idx` bigint(20) DEFAULT NULL,
  `quiz_idx` bigint(20) DEFAULT NULL,
  `is_answer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`quiz_history_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_history`
--

LOCK TABLES `quiz_history` WRITE;
/*!40000 ALTER TABLE `quiz_history` DISABLE KEYS */;
INSERT INTO `quiz_history` VALUES (3,'2023-10-05 17:15:29.208802',31,14,'N'),(4,'2023-10-05 17:16:17.924004',31,14,'Y'),(5,'2023-10-05 08:25:13.184337',31,14,'Y'),(6,'2023-10-05 17:45:49.320978',31,14,'Y'),(7,'2023-10-05 15:51:52.420247',3,32,'N'),(8,'2023-10-05 16:02:18.379615',3,17,'Y'),(9,'2023-10-05 16:02:20.401133',3,26,'N'),(10,'2023-10-05 16:02:21.966462',3,15,'N'),(11,'2023-10-05 16:02:31.201546',3,27,'Y'),(12,'2023-10-05 16:02:31.794384',3,19,'N'),(13,'2023-10-05 16:02:36.720306',3,26,'N'),(14,'2023-10-05 16:02:37.260672',3,31,'N'),(15,'2023-10-05 16:02:37.731330',3,18,'N'),(16,'2023-10-05 16:02:38.237675',3,33,'N'),(17,'2023-10-05 16:02:38.733254',3,36,'Y'),(18,'2023-10-05 16:22:33.253134',3,43,'N'),(19,'2023-10-05 16:22:34.472328',3,36,'N'),(20,'2023-10-05 16:22:35.115610',3,37,'N'),(21,'2023-10-06 01:55:52.124379',3,32,'N'),(22,'2023-10-06 01:56:28.662554',3,32,'N'),(23,'2023-10-06 02:01:20.516152',3,32,'N'),(24,'2023-10-06 02:01:43.644300',3,32,'N'),(25,'2023-10-06 02:01:48.299110',3,32,'N'),(26,'2023-10-06 02:01:51.817846',3,32,'N'),(27,'2023-10-06 02:02:23.283960',3,32,'Y'),(28,'2023-10-06 02:02:30.713793',3,32,'N'),(29,'2023-10-06 02:02:34.110219',3,32,'N'),(30,'2023-10-06 02:02:37.521069',3,32,'Y'),(31,'2023-10-06 02:10:19.478605',3,32,'Y'),(32,'2023-10-05 17:34:38.860795',9,34,'Y'),(33,'2023-10-05 17:35:04.168925',9,24,'N'),(34,'2023-10-05 18:13:08.603411',64,43,'N'),(35,'2023-10-05 18:13:08.763646',64,30,'N'),(36,'2023-10-06 00:18:46.731025',3,27,'Y'),(37,'2023-10-06 00:18:47.689320',3,39,'N'),(38,'2023-10-06 00:18:48.465744',3,40,'N'),(39,'2023-10-06 00:18:49.168467',3,20,'N'),(40,'2023-10-06 00:18:49.842269',3,19,'N'),(41,'2023-10-06 04:16:29.814201',86,43,'Y'),(42,'2023-10-06 04:16:30.028283',86,43,'Y'),(43,'2023-10-06 04:16:33.195368',86,43,'Y'),(44,'2023-10-06 04:16:33.757109',86,43,'Y'),(45,'2023-10-06 04:16:33.907052',86,43,'Y'),(46,'2023-10-06 04:16:33.967539',86,43,'Y'),(47,'2023-10-06 04:16:34.179551',86,43,'Y'),(48,'2023-10-06 04:16:39.926634',86,43,'Y'),(49,'2023-10-06 04:16:45.507577',86,43,'Y'),(50,'2023-10-06 04:16:46.163574',86,43,'Y'),(51,'2023-10-06 04:16:48.166093',86,43,'Y');
/*!40000 ALTER TABLE `quiz_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'mwonimoneydb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 15:21:58
